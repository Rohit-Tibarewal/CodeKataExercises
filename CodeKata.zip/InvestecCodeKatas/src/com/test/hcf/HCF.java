/**
 This program is to find the Highest Common Factor for a given array of integers
 *
 * @author  Rohit Tibarewal
 * @version 1.0
 * @since   14-02-2019 
 */
package com.test.hcf;

import java.util.Scanner;

public class HCF {

	/** This is the method to find the HCF using Euclidean Algorithm
	 * @param Array of integers
	 * @return HCF of the input array
	 */
	public static int highestCommonFactor(int[] numbers) {
		//declare and initialise a variable to store the HCF(Highest Common Factor)
		int hcf=1;
		//variable to keep track of array index
		int index=2;
		//check if array has just a single element
		if(numbers.length==1){
			//the first element itself is the HCF
			hcf=numbers[0];
		}
		//if array has more than one elements
		if(numbers.length>1){
			//invoke a recursive function to calculate HCF of first two elements
			hcf=calculateHCF(numbers[0],numbers[1]); 
		}
		//loop over the length of array to find HCF
		while(index<numbers.length){
			hcf=calculateHCF(hcf,numbers[index]);
			index++;
		}
		return hcf;
	}

	/**
	 * Recursive function to calculate the HCF of two numbers
	 * @param num1
	 * @param num2
	 * @return
	 */
	public static int calculateHCF(int num1,int num2){
		if (num2 == 0){
			return num1;
		}
		return calculateHCF(num2, num1 % num2);  
	}
	
	/** The Main method
	 * @param args
	 */
	public static void main(String[] args) {
		//use Scanner Object to get input array from user
		Scanner s=new Scanner(System.in);

		System.out.println("=================================================================================================");
		System.out.println("Program to Find the Highest Common Factor(H.C.F.) for given set of Integers");
		System.out.println("=================================================================================================");
		System.out.println("\nPlease enter the length of array?");

		try{
			//store the length of array
			int lengthOfArray=s.nextInt();
			//check if length of array is positive
			if(lengthOfArray<=0){
				throw new NegativeValueException("Please provide positive Integer value as Length of Array");
			}
			
			//declare an array of integers
			int numbers[]=new int[lengthOfArray];
			System.out.println("\nPlease Enter Integer value elements for this array:");

			for(int i=0;i<lengthOfArray;i++){
				//for reading the input array
				numbers[i]=s.nextInt();
			}
			System.out.print("\n*** Highest Common Factor of number(s) ");
			for(int i=0;i<numbers.length;i++){
				System.out.print(" "+numbers[i]+" ");
			}
			System.out.println(" is ***");
			//invoke function to calculate HCF
			int hcf=highestCommonFactor(numbers);
			//check that HCF should be positive integer
			if(hcf<0){
				//make it positive
				hcf = hcf*(-1);
			}
			System.out.println("H.C.F. = "+hcf);
		}
		catch(NegativeValueException e){
			System.out.println("***ERROR occurred...");
			System.out.println("***"+e.getMessage());
			System.out.println("***Exiting...");
			System.exit(0);
		}
		catch(Exception e){
			System.out.println("");
			System.out.println("***ERROR occurred...");
			System.out.println("***Please make sure to provide Integer values only!");
			System.out.println("***Exiting with error...");
			e.printStackTrace();
			System.exit(0);
		}
	}
}
