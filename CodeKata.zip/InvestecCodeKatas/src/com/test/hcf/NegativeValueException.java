package com.test.hcf;

public class NegativeValueException extends Exception {

	private String message;
	
	public NegativeValueException(String string) {
		setMessage(string);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
