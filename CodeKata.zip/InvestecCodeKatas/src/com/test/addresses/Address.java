/**
 * 
 */
package com.test.addresses;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author roti
 *
 */

@JsonIgnoreProperties(value = { "id", "lastUpdated","suburbOrDistrict"}, ignoreUnknown = true)
public class Address {

	private String id;
	private Map<String, String> type;
	private Map<String, String> addressLineDetail;
	private String cityOrTown;
	private Map<String, String> provinceOrState;
	private String postalCode;
	private Map<String, String> country;
	private String lastUpdated;
	private String suburbOrDistrict;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Map<String, String> getType() {
		return type;
	}
	public void setType(Map<String, String> type) {
		this.type = type;
	}
	public Map<String, String> getAddressLineDetail() {
		return addressLineDetail;
	}
	public void setAddressLineDetail(Map<String, String> addressLineDetail) {
		this.addressLineDetail = addressLineDetail;
	}
	public Map<String, String> getProvinceOrState() {
		return provinceOrState;
	}
	public void setProvinceOrState(Map<String, String> provinceOrState) {
		this.provinceOrState = provinceOrState;
	}
	public String getCityOrTown() {
		return cityOrTown;
	}
	public void setCityOrTown(String cityOrTown) {
		this.cityOrTown = cityOrTown;
	}
	public Map<String, String> getCountry() {
		return country;
	}
	public void setCountry(Map<String, String> country) {
		this.country = country;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getSuburbOrDistrict() {
		return suburbOrDistrict;
	}
	public void setSuburbOrDistrict(String suburbOrDistrict) {
		this.suburbOrDistrict = suburbOrDistrict;
	}

}
