/**
 This program implements an application that
 * performs various operations on array of Addresses, captured from JSON input file.
 *
 * @author  Rohit Tibarewal
 * @version 1.0
 * @since   14-02-2019 
 */
package com.test.addresses;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class HandleAddresses {

	//Declare an array list to store all Error messages in case an Address is Invalid
	private static ArrayList<String> errorMessages= new ArrayList<String>();

	/**
	 * This method is used to a pretty print version of an address in the given format
	 * @param address This is the input Address object parameter, which needs to be printed
	 * @return This returns JSON string in pretty print version
	 */
	private static String prettyPrintAddress(Address address) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			String jsonString=  mapper.writerWithDefaultPrettyPrinter().writeValueAsString(address);
			return jsonString;

		} catch (Exception e) {
			return "****ERROR: Unfortunately, Pretty Printing failed";
		}
	}


	/**
	 * Function to get Array of addresses from a given JSON input file
	 * @param pathToJSONFile
	 * @return
	 * @throws IOException
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 */
	private static Address[] getArrayOfAddresses(String pathToJSONFile) {
		//Create a new ObjectMapper object
		ObjectMapper mapper = new ObjectMapper();
		//Get the Array of Addresses from the input JSON file
		Address[] arrayOfAddresses;
		try {
			arrayOfAddresses = mapper.readValue(new File(pathToJSONFile), Address[].class);
			return arrayOfAddresses;
		} 
		catch(Exception e){
			e.printStackTrace();
			System.out.println("***ERROR occurred...");
			System.out.println("***Please make sure to provide a correct input JSON file with Array of Addresses.");
			System.out.println("***Exiting...");
			System.exit(0);
			return null;
		}
		
	}


	/**
	 * This method is used to pretty print version of all the Addresses obtained from an Input JSON file
	 * @param pathToJSONFile This parameter holds the Path to JSON File, which contains array of Addresses
	 * @return Nothing
	 */
	private static void prettyPrintAllAddress(String pathToJSONFile) {
		try {

			Address[] arrayOfAddresses = getArrayOfAddresses(pathToJSONFile);
			//loop over the array and print each Address
			for(int i=0;i<arrayOfAddresses.length;i++){
				System.out.println("--------------------------------------------------------------------------");
				System.out.println((i+1)+".Address is :  ");
				System.out.println(prettyPrintAddress(arrayOfAddresses[i]));
			}

		} 
		catch(Exception e){
			System.out.println("****ERROR:\n Exception occurred");
			e.printStackTrace();
		}
	}

	/** 
	 * This method is used to print a Particular "Type" of Address
	 * @param pathToJSONFile This parameter holds the Path to JSON File, which contains array of Addresses
	 * @param typeOfAddress: The 'Type' of address to be printed
	 * @return Nothing
	 */
	private static void printParticularTypeAddress(String pathToJSONFile,String typeOfAddress) {
		boolean foundAddress=false;
		try {
			Address[] arrayOfAddresses = getArrayOfAddresses(pathToJSONFile);

			for(int i=0;i<arrayOfAddresses.length;i++){
				//check if Type is there for this Address
				if(arrayOfAddresses[i].getType()!=null){
					//check if the address type matches and print accordingly
					if(arrayOfAddresses[i].getType().get("name")!=null && arrayOfAddresses[i].getType().get("name").equalsIgnoreCase((typeOfAddress+" Address"))){
						foundAddress=true;
						System.out.println("The below address is of Type: "+arrayOfAddresses[i].getType().get("name"));
						//print the address
						System.out.println(prettyPrintAddress(arrayOfAddresses[i]));
					}
				}
			}
			if(!foundAddress){
				System.out.println("****ERROR: Could not find any Address of Type: "+typeOfAddress);
			}

		} 	
		catch(Exception e){
			System.out.println("****ERROR:\n Exception occurred");
			e.printStackTrace();
		}
	}


	/** Function to check if a given Address has a Numeric Postal code
	 * @param address
	 * @return
	 */
	private static boolean isPostalCodeNumeric(Address address) {
		boolean isNumeric=false;
		try {
			//check if Postal code is provided or not
			if(address.getPostalCode()!=null){
				//check if Postal Code is Numeric
				Double.parseDouble(address.getPostalCode());
				isNumeric=true;
			}
			else{
				//populate error message list
				errorMessages.add("The Postal Code is Missing for this Address.");
			}
			return isNumeric;
		} catch (NumberFormatException e) {
			//populate error message list
			errorMessages.add("The Postal code is NOT Numeric for this Address.");
			return false;
		}	
	}

	/** Function to check if a given Address has a Country and also a Province for ZA country codes
	 * @param address
	 * @return
	 */
	private static boolean hasCountry(Address address) {
		boolean hasCountry=false;
		//if Country is missing then return false
		if(address.getCountry()==null){
			//populate error message list
			errorMessages.add("The Country is missing for this Address.");
			hasCountry=false;
			return hasCountry;
		}
		if(address.getCountry().get("code")!=null && (!address.getCountry().get("code").equalsIgnoreCase("ZA"))){
			hasCountry=true;
		}
		//check if country code is ZA then does it has a Province
		else if(address.getCountry().get("code")!=null && address.getCountry().get("code").equalsIgnoreCase("ZA")){
			hasCountry=checkProvince(address);
		}

		return hasCountry;
	}

	/** Function to check if a given Address has a Province
	 * @param address
	 * @return
	 */
	private static boolean checkProvince(Address address) {
		boolean hasProvince=false;
		if(address.getProvinceOrState()!=null){
			//check if not null and not empty
			if(address.getProvinceOrState().get("code")!=null && (!address.getProvinceOrState().get("code").isEmpty())){
				hasProvince=true;
			}
		}
		if(!hasProvince){
			//populate error message list
			errorMessages.add("The country code for this Address is \"ZA\" but this address does NOT has a Province.");
		}
		return hasProvince;

	}

	/** Function to check if a given Address has an addressLineDetail or not
	 * @param address
	 * @return
	 */
	private static boolean checkAddressLine(Address address) {
		boolean hasAddressLine=false;
		if(address.getAddressLineDetail()!=null){
			//get 'line1' property
			String line1=address.getAddressLineDetail().get("line1");
			//get 'line2' property
			String line2=address.getAddressLineDetail().get("line2");
			//check that at least one address line is not blank or null
			if( (line1!=null && (!line1.isEmpty())) || (line2!=null && (!line2.isEmpty()))){
				hasAddressLine=true;
			}
		}
		if(!hasAddressLine){
			//populate error message list
			errorMessages.add("No Address Line provided for this Address.");
		}
		return hasAddressLine;
	}


	/** 
	 * Function to check if an Address is Valid or Not
	 * @param pathToJSONFile This parameter holds the Path to JSON File, which contains array of Addresses
	 * @return Nothing
	 */
	private static void validateAddress(String pathToJSONFile) {
		try {
			//get the array of addresses
			Address[] arrayOfAddresses = getArrayOfAddresses(pathToJSONFile);
			System.out.println("------------------------------------------------------------------------- ");
			//loop over the address array
			for(int i=0;i<arrayOfAddresses.length;i++){
				//reset error messages for each new Address to be checked
				errorMessages= new ArrayList<String>();
				System.out.println("Check for Address no."+(i+1)+":\n ");
				System.out.println(prettyPrintAddress(arrayOfAddresses[i]));
				//store results of each Validity check
				boolean check1 = isPostalCodeNumeric(arrayOfAddresses[i]);
				boolean check2 = hasCountry(arrayOfAddresses[i]);
				boolean check3 = checkAddressLine(arrayOfAddresses[i]);

				//check if Address is Valid i.e. if all conditions passed
				if(check1 && check2 && check3){
					//print success message
					System.out.println("***SUCCESS: This is a VALID Address");
				}
				else{
					//Display message as to why the Address is Invalid 
					System.out.println("***INVALID: This is an INVALID Address. Because of below "+ errorMessages.size() +" reason(s):");
					int count=0;
					for (String message : errorMessages) 
						System.out.println((++count)+"."+message + " "); 
				}
				System.out.println("\n------------------------------------------------------------------------------------------------ ");
			}

		} 	
		catch(Exception e){
			System.out.println("****ERROR:\n Exception occurred");
			e.printStackTrace();
		}
	}


	public static void main(String[] args) {
		
		//check if JSON file path is provided as command line argument or not
		if(args.length<=0){
			//throw error and exit
			System.out.println("***ERROR:\n Please provide JSON File path, within double quotes, as a commad line input argument.");
			System.out.println("***Exiting...");
			System.exit(0);
		}
		//declare a string to store JSON file's path
		String pathToJSONFile=args[0];

		//create a new test Address object to be pretty printed
		Address address= new Address();
		address.setId("2");
		address.setLastUpdated("2019-02-14T00:00:00.000Z");
		Map<String, String> type = new HashMap<String, String>();
		type.put("code", "1");
		type.put("name", "Physical Address");
		address.setType(type);
		Map<String, String> country = new HashMap<String, String>();
		country.put("code", "LB");
		country.put("name", "Lebanon");
		address.setCountry(country);
		address.setCityOrTown("City 2");
		address.setPostalCode("2345");

		System.out.println("");
		System.out.println("***************************************************");
		System.out.println("Pretty Print the Test Address JSON object");
		System.out.println("***************************************************");
		System.out.println("");
		//pretty print the above test address
		System.out.println(prettyPrintAddress(address));

		System.out.println("");
		System.out.println("***************************************************");
		System.out.println("Pretty Print All Addresses present in JSON file");
		System.out.println("***************************************************");
		System.out.println("");
	
		//pretty print all addresses in a given JSON input file
		prettyPrintAllAddress(pathToJSONFile);


		System.out.println("");
		System.out.println("***************************************************");
		System.out.println("Pretty Print Address of a given TYPE");
		System.out.println("***************************************************");
		System.out.println("");
		System.out.println("=====USER INPUT REQUIRED=====");
		System.out.println("");
		System.out.println("Please Enter the Type of Address you wish to Search like (postal, physical, business):");
		//Wait to get user input for the Type of address to be printed
		Scanner scanner = new Scanner(System.in);
		String type_of_address = scanner.nextLine();
		//to print an address of a certain type 
		printParticularTypeAddress(pathToJSONFile,type_of_address);

		//check if JSON file path is provided as command line argument or not
		if(type_of_address==null && type_of_address.isEmpty()){
			//throw error and exit
			System.out.println("***ERROR:\n Please provide JSON File path, within double quotes, as a commad line input argument.");
			System.out.println("***Exiting...");
			System.exit(0);
		}
		
		System.out.println("");
		System.out.println("***************************************************");
		System.out.println("Check Validity of Addresses");
		System.out.println("***************************************************");
		System.out.println("");
		//check Address Validity
		validateAddress(pathToJSONFile);

	}

}
