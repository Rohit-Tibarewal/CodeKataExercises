package com.test.stringops;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Calcuate {
	public static int add(String numbers){
		int total;
		System.out.println("\nCalculate Total for given string "+numbers);
		if(numbers.isEmpty()){
			total= 0;
		}
		else{
			String[] tokens = tokenize(numbers);
			List<String> listOfNumbers = Arrays.<String>asList(tokens);

			if(!isAllNonNegativeNumbers(listOfNumbers)){
				return 0;
			}
			//find the total sum of all integer values in string
			total= sumOf(listOfNumbers);
		}
		System.out.println("Total= "+total);
		return (total);	
	}

	/**
	 * Function to check if all input values are non-negative
	 * @param listOfNumbers
	 * @return
	 */
	private static boolean isAllNonNegativeNumbers(List<String> listOfNumbers) {
		boolean isAllNonNegative=true;
		//get the list of Negative values from the list
		List<String> listOfNegativeNumbers = getNEgativeNumber(listOfNumbers);
		//check if negative values found
		if(listOfNegativeNumbers.size()>0){
			//set the return value
			isAllNonNegative=false;
			try {
				//throw an Exception
				throw new NegativeNumberException("Negatives not allowed!");
			} catch (NegativeNumberException e) {
				System.out.println("\n****ERROR: Exception occurred with message:\n "+e.getMessage());
				System.out.println("Below are the list of negative numbers in the given input string:");
				//iterate over list of Negative values and print them
				for (String item : listOfNegativeNumbers) {
					System.out.print(" "+item);
				}
				System.out.println();
			}
		}
		return isAllNonNegative;
	}

	/**
	 * Function to get all Negative numbers from a given list
	 * @param listOfNumbers
	 * @return
	 */
	private static List<String> getNEgativeNumber(List<String> listOfNumbers) {
		List<String> listOfNegativeNumbers = new ArrayList<String>();
		for (String item : listOfNumbers) {
			//check if number is negative
			if(convertToInt(item)<0){
				//add item to list
				listOfNegativeNumbers.add(item);
			}
		}
		return listOfNegativeNumbers;
	}

	/**
	 * Function to Split a given string based on delimiters
	 * @param numbers
	 * @return
	 */
	private static String[] tokenize(String numbers) {
		if(numbers.isEmpty()){
			return new String[0];
		}
		//check if String starts with custom Delimiters
		else if(useCustomDelimiterSyntax(numbers)){
			//Split the string based on custom delimiter
			return splitUsingCustomDelimiter(numbers);
		}
		else{
			//Split the string based on default delimiters
			return splitUsingNewLineAndComma(numbers);
		}
	}

	/**
	 * Function to check if string starts with special delimiter
	 * @param numbers
	 * @return
	 */
	private static boolean useCustomDelimiterSyntax(String numbers) {
		return numbers.startsWith("//");
	}

	/**
	 * Function to Split a string based on default delimiters i.e. Comma and NewLine
	 * @param numbers
	 * @return
	 */
	private static String[] splitUsingNewLineAndComma(String numbers) {
		String[] tokens=numbers.split(",|\n");
		return tokens;
	}

	/**
	 * Function to Split the string using a custom delimiter
	 * @param numbers
	 * @return
	 */
	private static String[] splitUsingCustomDelimiter(String numbers) {
		//check if string has custom delimiter
		Matcher m= Pattern.compile("//(.)\n(.*)").matcher(numbers);
		//String to store all the custom delimiters
		String customDelimiter = numbers.substring(numbers.indexOf("//") + 2,numbers.indexOf("\n"));
		//get the substring of numbers to be parsed
		numbers = numbers.substring(numbers.indexOf('\n') + 1);

		if(!m.matches()){
			//Create a Regular expression to match the condition
			String regex="(?<=\\[).+?(?=\\])";
			Pattern p=Pattern.compile(regex);
			//check if delimiter matches the criteria
			Matcher mDelim= p.matcher(customDelimiter);
			//Initialise a string to store list of all delimiters
			String delimiters = "";
			//loop over all delimiters
			while(mDelim.find())
			{
				//generate a list of pipe separated delimiters, to be used for split function
				delimiters += mDelim.group() + "|";

			}
			//remove the last pipe
			String tempStr=delimiters.substring(0, delimiters.length()-1);
			String newString=tempStr.replace("*", "\\*");
			//return the split values based on list of delimiters
			return numbers.split(newString);

		}
		else{
			//return the split values based on single delimiter
			return numbers.split(customDelimiter);
		}

	}

	/** Function to calculate the total sum of integer values present in a given String
	 * @param listOfNumbers
	 * @return
	 */
	private static int sumOf(List<String> listOfNumbers) {
		int sum=0;
		for (String item : listOfNumbers) {
			//check if number is too big then do not add it for total
			if(convertToInt(item)<=1000){
				sum+=convertToInt(item);
			}
		}
		return sum;
	}


	/** Function to get the Integer value of a String
	 * @param numbers
	 * @return
	 */
	private static int convertToInt(String number) {
		return Integer.parseInt(number);
	}

}
