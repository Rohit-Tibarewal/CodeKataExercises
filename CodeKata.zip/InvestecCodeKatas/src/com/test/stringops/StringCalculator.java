/**
 This program implements an application that
 * performs various operations on Strings, captured from user input.
 *
 * @author  Rohit Tibarewal
 * @version 1.0
 * @since   14-02-2019 
 */
package com.test.stringops;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringCalculator {

	@Test 
	public void zeroOrEmpty(){
		assertEquals(0,Calcuate.add(""));
	}
	
	@Test
	public void returnNumberItself(){
		assertEquals(1, Calcuate.add("1"));
	}
	
	@Test
	public void returnSumOfTwoNumbersDelimitedByComma(){
		assertEquals(3, Calcuate.add("1,2"));
	}
	
	@Test
	public void returnSumOfMultipleNumbersDelimitedByComma(){
		assertEquals(11, Calcuate.add("1,2,3,5"));
	}
	
	@Test
	public void acceptNewLineAsDelimiter(){
		assertEquals(10, Calcuate.add("1,2\n3\n4"));
	}
	
	@Test
	public void acceptCustomDelimiter(){
		assertEquals(5, Calcuate.add("//;\n4;1"));
	}
	
	@Test
	public void raiseExceptinOnNegativeValues(){
			Calcuate.add("1,2,-3,-9,-8,7,0");
			//fail("Exception occurred.");
	}
	
	@Test
	public void acceptAnyCustomDelimiters(){
		assertEquals(13, Calcuate.add("//[****][,,][;;]\n4****4,,1;;4"));
	}
}
