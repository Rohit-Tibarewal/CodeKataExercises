package com.test.stringops;

public class NegativeNumberException extends Exception {
	private String message;

	public NegativeNumberException(String string) {
		setMessage(string);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
